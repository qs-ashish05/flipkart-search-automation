from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.chrome.options import Options as ChromeOptions
from selenium.webdriver.firefox.options import Options as FirefoxOptions
from selenium.webdriver.safari.options import Options as SafariOptions
from selenium.webdriver.edge.options import Options as EdgeOptions
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time

def utilize(driver):
    # URL to test
    url = "https://www.flipkart.com/"

    # Load URL and maximize window
    driver.get(url)
    driver.maximize_window()
    try:
    # Handle pop-up if present
        cross = driver.find_element(By.CLASS_NAME, "_30XB9F")
        cross.click()
    except:
        pass
    # Searching for the product
    search_item = "Samsung Galaxy S10"  
    search_bar = WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.NAME, "q")))
    search_bar.send_keys(search_item + Keys.ENTER)

    # Applying required filters
    try:
        assured = WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.XPATH, '//*[@id="container"]/div/div[3]/div[1]/div[1]/div/div[1]/div/section[4]/label')))
        brand = WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.XPATH, '/html/body/div/div/div[3]/div[1]/div[1]/div/div[1]/div/section[3]/div[2]/div/div/div/label')))
        price_filter = WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.XPATH, '/html/body/div/div/div[3]/div/div[2]/div[1]/div/div/div[2]/div[4]')))
    except:
        # geting the required filter clicks
        assured = driver.find_element(By.XPATH, '//*[@id="container"]/div/div[3]/div[1]/div[1]/div/div[1]/div/section[4]/label')
        brand = driver.find_element(By.XPATH, '/html/body/div/div/div[3]/div[1]/div[1]/div/div[1]/div/section[3]/div[2]/div/div/div/label')
        price_filter = driver.find_element(By.XPATH, '/html/body/div/div/div[3]/div/div[2]/div[1]/div/div/div[2]/div[4]')
    
    # Perform filter clicks
    brand.click()
    time.sleep(2)  # Adding sleep for stability
    assured.click()
    time.sleep(2)  # Adding sleep for stability
    price_filter.click()
    time.sleep(2)  # Adding sleep for stability

    # Scraping the products
    names = WebDriverWait(driver, 10).until(EC.presence_of_all_elements_located((By.CLASS_NAME, '_4rR01T')))
    prices = WebDriverWait(driver, 10).until(EC.presence_of_all_elements_located((By.CLASS_NAME, '_25b18c')))
    product_link_element = WebDriverWait(driver, 10).until(EC.presence_of_all_elements_located((By.CLASS_NAME, "_1fQZEK")))
    links = [item.get_attribute("href") for item in product_link_element]

    # Print product details
    for i in range(len(names)):
        count = i+1
        print(f"Product_no. {count}")
        print(f"Product_Name: {names[i].text}")
        temp = prices[i].text.split('\n')[0]
        print(f"Display_Price: {temp}")
        print(f"Link_To_Page: {links[i]}")
        print('\n')

try:
    options = SafariOptions()
    driver = webdriver.Chrome(options=options)
except:
    try:
        options = FirefoxOptions()
        driver = webdriver.Chrome(options=options)
    except:
        try:
            options = EdgeOptions()
            driver = webdriver.Chrome(options=options)
        except:
            try:
                options =  ChromeOptions()   
                driver = webdriver.Chrome(options=options)            
            except:
                print("Nothing happend")
                exit(0)

utilize(driver)


time.sleep(10)
driver.quit()

# https://automate.browserstack.com/dashboard/v2/quick-start/ci-cd-pipeline